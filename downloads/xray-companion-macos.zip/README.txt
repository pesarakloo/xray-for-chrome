Xray for Chrome - macOS companion (package v0.7.5)

1. Open the installed extension > Setup guide > Chrome Web Store > macOS.
2. Extract this ZIP. Open the folder containing install.command.
3. Open Terminal, type cd and a space, drag this folder into Terminal, then press Enter.
4. Copy the Mac install command from that extension's guide and run it here.
   It starts with /bin/zsh ./install.command and includes --extension-id.
5. Wait for success, quit Chrome with Cmd+Q and reopen it. Check the core in Connect.

Automatic downloads use Xray 25.8.3 for Intel or Apple Silicon, not the latest release.
For VLESS Encryption, add --xray-version v26.6.27 to the guide's install command.
This explicitly replaces the core with 26.6.27 (upstream pre-release).
Do not combine --xray-version with --xray. A normal reinstall restores 25.8.3.
Disconnect first and restart Chrome after installation.
No sudo or Xcode is needed. For a local binary, add --xray "/path/to/xray".
To remove the companion, disconnect and run /bin/zsh ./uninstall.command here.
For the full GitHub project, choose GitHub installation in the guide; its Mac
scripts are under native-hosts/macos/ instead. Persian instructions: README.fa.txt
