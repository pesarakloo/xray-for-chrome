Xray for Chrome - macOS companion (v0.7.4)

1. Quit Chrome (Cmd+Q) and disconnect the extension if it is connected.
2. Double-click the ZIP to extract it.
3. Right-click "install.command" in the extracted folder, choose Open, then Open again.
   (macOS asks for this once because the file was downloaded from the internet.)
4. Wait for the installation-complete message and reopen Chrome.

Installed from the Chrome Web Store? Open the extension's Setup guide and copy the
macOS command (it includes your extension ID) and run it in Terminal instead.

To remove the companion later, right-click "uninstall.command" > Open.
