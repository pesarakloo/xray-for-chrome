Xray for Chrome - Windows companion (v0.7.4)

1. Close Chrome and disconnect the extension if it is connected.
2. Extract this whole ZIP (right-click > Extract All).
3. Double-click install-windows.cmd and wait for "Installation completed successfully".
4. Reopen Chrome.

Installed from the Chrome Web Store? Open the extension's Setup guide, copy the
Windows command (it includes your extension ID) and run it in PowerShell from
this folder instead of double-clicking.

To remove the companion later, double-click uninstall-windows.cmd.
