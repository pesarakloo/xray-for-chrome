Xray for Chrome - Windows companion (package v0.7.5)

1. Open the installed extension > Setup guide > Chrome Web Store > Windows.
2. Download and fully extract this ZIP. Open the folder containing install-windows.cmd.
3. Type powershell in File Explorer's address bar and press Enter.
4. Copy the Windows install command from that extension's guide and run it here.
   It includes -ExtensionId with the actual installed extension ID.
5. Wait for success, fully close and reopen Chrome, then check the core in Connect.

A fresh install downloads Xray 25.8.3. Normal reinstalls keep an existing core.
Administrator access is not normally required. For a local binary, use -XrayExe.
To remove the companion, disconnect and run .\uninstall-windows.cmd from this folder.
For the full GitHub project instead of this small ZIP, choose GitHub installation
in the guide. Persian instructions: README.fa.txt
